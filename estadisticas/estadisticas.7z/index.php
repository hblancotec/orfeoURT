<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<frameset rows="342*,119*" cols="*" framespacing="0"" frameborder="NO" border="0">
  <frame src="vistaFormConsulta.php?<?=krd=$krd?>" name="topFrame" >
  <frame src="file:///C|/ApacheVI/Apache2/htdocs/orfeoInter/Untitled-2" name="mainFrame">
</frameset>
<noframes><body>
</body></noframes>
</html>
